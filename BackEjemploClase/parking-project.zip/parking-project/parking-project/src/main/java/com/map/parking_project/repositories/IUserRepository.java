package com.map.parking_project.repositories;

public interface IUserRepository {

}
