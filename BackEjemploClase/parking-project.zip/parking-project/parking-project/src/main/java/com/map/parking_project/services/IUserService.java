package com.map.parking_project.services;

public interface IUserService {

}
