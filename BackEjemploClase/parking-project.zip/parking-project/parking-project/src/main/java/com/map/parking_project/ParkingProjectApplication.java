package com.map.parking_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingProjectApplication.class, args);
	}

}
