package com.map.parking_project.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.map.parking_project.models.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.*;


@RestController
@RequestMapping("/api/map-project")

public class UserController {

@GetMapping("/getAll")
    public List<User> getAll() {
    //return User.findAll();
}


}
