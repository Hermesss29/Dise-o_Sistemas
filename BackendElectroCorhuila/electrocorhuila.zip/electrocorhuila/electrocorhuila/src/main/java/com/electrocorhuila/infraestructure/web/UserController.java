package com.electrocorhuila.infraestructure.web;


import com.electrocorhuila.domain.model.User;
import com.electrocorhuila.domain.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public User createUser(@RequestParam String name, @RequestParam int estrato) {
        return userService.registerUser(name, estrato);
    }
}

