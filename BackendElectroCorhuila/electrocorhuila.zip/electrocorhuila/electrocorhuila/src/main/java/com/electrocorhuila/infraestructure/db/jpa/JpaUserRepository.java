package com.electrocorhuila.infraestructure.db.jpa;

import com.electrocorhuila.infraestructure.db.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JpaUserRepository extends JpaRepository<UserEntity, Long> {
}