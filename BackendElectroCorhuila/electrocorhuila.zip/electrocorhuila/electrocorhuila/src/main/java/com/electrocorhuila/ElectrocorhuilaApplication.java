package com.electrocorhuila;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectrocorhuilaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectrocorhuilaApplication.class, args);
	}

}
