package com.electrocorhuila.infraestructure.db.jpa;

import com.electrocorhuila.domain.model.User;
import com.electrocorhuila.domain.repository.UserRepository;
import com.electrocorhuila.infraestructure.db.entity.UserEntity;
import org.springframework.stereotype.Repository;

import org.springframework.beans.factory.annotation.Autowired;

import com.electrocorhuila.domain.model.User;
import com.electrocorhuila.domain.repository.UserRepository;
import com.electrocorhuila.infraestructure.db.entity.UserEntity;
import org.springframework.stereotype.Repository;

import org.springframework.beans.factory.annotation.Autowired;

@Repository
public class UserRepositoryImpl implements UserRepository {

    @Autowired
    private JpaUserRepository jpaRepo;

    @Override
    public User save(User user) {
        UserEntity entity = new UserEntity();
        entity.setName(user.getName());
        entity.setEstrato(user.getEstrato());
        entity.setTarifa(user.getTarifa());

        UserEntity saved = jpaRepo.save(entity);
        return new User(saved.getId(), saved.getName(), saved.getEstrato());
    }

    @Override
    public User findById(Long id) {
        UserEntity entity = jpaRepo.findById(id).orElseThrow();
        return new User(entity.getId(), entity.getName(), entity.getEstrato());
    }
}