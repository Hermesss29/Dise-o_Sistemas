package com.electrocorhuila.domain.repository;

import com.electrocorhuila.domain.model.User;

public interface UserRepository {
    User save(User user);
    User findById(Long id);
}