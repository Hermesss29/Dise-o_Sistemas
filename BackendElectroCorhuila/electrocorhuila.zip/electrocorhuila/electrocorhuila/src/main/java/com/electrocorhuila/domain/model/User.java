package com.electrocorhuila.domain.model;

public class User {
    private Long id;
    private String name;
    private int estrato;
    private double tarifa;

    public User(Long id, String name, int estrato) {
        this.id = id;
        this.name = name;
        this.estrato = estrato;
        this.tarifa = calculateTarifa(estrato);
    }

    private double calculateTarifa(int estrato) {
        switch (estrato) {
            case 1: return 10000;
            case 2: return 15000;
            case 3: return 20000;
            case 4: return 25000;
            case 5: return 30000;
            default: return 35000;
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEstrato() {
        return estrato;
    }

    public void setEstrato(int estrato) {
        this.estrato = estrato;
    }

    public double getTarifa() {
        return tarifa;
    }

    public void setTarifa(double tarifa) {
        this.tarifa = tarifa;
    }

    // Getters y Setters
}