package com.electrocorhuila.application;


import com.electrocorhuila.domain.model.User;
import com.electrocorhuila.domain.repository.UserRepository;
import com.electrocorhuila.domain.service.UserService;
import org.springframework.stereotype.Service;


@Service
public class UserUseCase implements UserService {

    private final UserRepository userRepository;

    public UserUseCase(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User registerUser(String name, int estrato) {
        User user = new User(null, name, estrato);
        return userRepository.save(user);
    }
}