package com.electrocorhuila.domain.service;

import com.electrocorhuila.domain.model.User;

public interface UserService {
    User registerUser(String name, int estrato);
}