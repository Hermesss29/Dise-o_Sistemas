package com.PruebaUnitaria.backend.application.service;

import com.PruebaUnitaria.backend.domain.model.Usuario;
import com.PruebaUnitaria.backend.domain.ports.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UsuarioServiceTest {

    private UsuarioRepository usuarioRepository;
    private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        usuarioRepository = mock(UsuarioRepository.class);
        usuarioService = new UsuarioService(usuarioRepository);
    }

    @org.testng.annotations.Test
    void registrarUsuario_deberiaRetornarUsuarioGuardado() {
        Usuario usuario = new Usuario(
                "Carlos Pérez", "CC", "123456789", "3101234567",
                LocalDate.of(1990, 1, 1), "Masculino"
        );

        when(usuarioRepository.registrar(any(Usuario.class))).thenReturn(usuario);

        Usuario resultado = usuarioService.registrarUsuario(usuario);

        assertNotNull(resultado);
        assertEquals("Carlos Pérez", resultado.getNombreCompleto());
        verify(usuarioRepository, times(1)).registrar(usuario);
    }
}
