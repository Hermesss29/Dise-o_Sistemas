package com.PruebaUnitaria.backend.domain.ports;

import com.PruebaUnitaria.backend.domain.model.Usuario;

public interface UsuarioRepository {
    Usuario registrar(Usuario usuario);
}