package com.PruebaUnitaria.backend.infrastructure.repository;

import com.PruebaUnitaria.backend.domain.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JpaUsuarioRepository extends JpaRepository<Usuario, Long> {
    // Puedes agregar consultas personalizadas aquí si las necesitas más adelante
}