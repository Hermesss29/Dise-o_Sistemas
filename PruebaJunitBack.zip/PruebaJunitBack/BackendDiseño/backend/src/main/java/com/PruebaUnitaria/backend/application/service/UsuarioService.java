package com.PruebaUnitaria.backend.application.service;

import com.PruebaUnitaria.backend.domain.model.Usuario;
import com.PruebaUnitaria.backend.domain.ports.UsuarioRepository;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Usuario registrarUsuario(Usuario usuario) {
        return usuarioRepository.registrar(usuario);
    }
}
