package com.PruebaUnitaria.backend.infrastructure.repository;

import com.PruebaUnitaria.backend.domain.model.Usuario;
import com.PruebaUnitaria.backend.domain.ports.UsuarioRepository;
import org.springframework.stereotype.Repository;

@Repository
public class UsuarioRepositoryImpl implements UsuarioRepository {

    private final JpaUsuarioRepository jpaUsuarioRepository;

    public UsuarioRepositoryImpl(JpaUsuarioRepository jpaUsuarioRepository) {
        this.jpaUsuarioRepository = jpaUsuarioRepository;
    }

    @Override
    public Usuario registrar(Usuario usuario) {
        return jpaUsuarioRepository.save(usuario);
    }
}
